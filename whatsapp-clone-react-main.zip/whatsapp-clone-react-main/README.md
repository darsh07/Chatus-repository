# Build a WhatsApp Clone with React JS, FireBase and Google Authentication

# Tech Stack
- React js
- Firebase Firestore Realtime DB
- Material UI
- React Router
- React Context API
- Redux
- Google Authentication

Credit: Clever Programmer (Rocking Guys)

Checkout detail for firebase setup here: https://youtu.be/pUxrDcITyjg 
